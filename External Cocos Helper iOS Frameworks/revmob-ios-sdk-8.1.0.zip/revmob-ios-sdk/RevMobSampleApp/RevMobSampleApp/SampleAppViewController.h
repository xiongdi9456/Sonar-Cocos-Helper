#import <UIKit/UIKit.h>
#import <RevMobAds/RevMobAds.h>
#import <RevMobAds/RevMobAdsDelegate.h>

#import <CoreLocation/CoreLocation.h>

@interface SampleAppViewController : UIViewController <RevMobAdsDelegate, CLLocationManagerDelegate>

@end
